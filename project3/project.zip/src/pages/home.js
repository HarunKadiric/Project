import React from 'react';
import { Container, Typography, Grid, Paper } from '@mui/material';
import Slideshow from '../components/slideshow'; // Import the Slideshow component

const Home = () => {
  return (
    <div className="full-width-container">
      {/* Slideshow Section */}
      <Slideshow />

      <Container>
        {/* Posts Section */}
        <Typography variant="h4" gutterBottom>
          Latest Posts
        </Typography>
        <Grid container spacing={3}>
          {/* Post 1 */}
          <Grid item xs={12} sm={6} md={4}>
            <Paper style={{ padding: '16px' }}>
              {/* Post image */}
              <img src="https://cdn.mos.cms.futurecdn.net/biPMkmHiPiVhYNUwWpmA2k.jpg" alt="Post 1" style={{ width: '100%', height: 'auto', marginBottom: '10px' }} />
              {/* Post title */}
              <Typography variant="h6" gutterBottom>
              The Rise of Battle Royale Games
              </Typography>
              {/* Post description */}
              <Typography variant="body2" gutterBottom>
              Explore how the battle royale genre has taken the gaming world by storm.
              </Typography>
              {/* Post author */}
              <Typography variant="body2" color="textSecondary">
                By Daniel Thompson
              </Typography>
            </Paper>
          </Grid>

          {/* Post 2 */}
          <Grid item xs={12} sm={6} md={4}>
            <Paper style={{ padding: '16px' }}>
              {/* Post image */}
              <img src="https://www.rappler.com/tachyon/2022/06/video-games-june-23-2022.jpg" alt="Post 2" style={{ width: '100%', height: 'auto', marginBottom: '10px' }} />
              {/* Post title */}
              <Typography variant="h6" gutterBottom>
              Top 10 Upcoming Games of 2024
              </Typography>
              {/* Post description */}
              <Typography variant="body2" gutterBottom>
              Get excited for the most anticipated games releasing this year.
              </Typography>
              {/* Post author */}
              <Typography variant="body2" color="textSecondary">
                By Jane Smith
              </Typography>
            </Paper>
          </Grid>

          {/* Add more posts as needed */}
          <Grid item xs={12} sm={6} md={4}>
            <Paper style={{ padding: '16px' }}>
              {/* Post image */}
              <img src="https://blog-images.fanatical.com/fanatical/c6784c62fc7190c9320dc1bc3bc60828ca17b7dc_getbetteratfpsgames-blog.jpg?auto=compress,format" alt="Post 3" style={{ width: '100%', height: 'auto', marginBottom: '10px' }} />
              {/* Post title */}
              <Typography variant="h6" gutterBottom>
              Tips and Tricks for Mastering FPS Games
              </Typography>
              {/* Post description */}
              <Typography variant="body2" gutterBottom>
              Improve your skills in first-person shooter games with these expert tips.
              </Typography>
              {/* Post author */}
              <Typography variant="body2" color="textSecondary">
                By Daniel Thompson
              </Typography>
            </Paper>
          </Grid>

          <Grid item xs={12} sm={6} md={4}>
            <Paper style={{ padding: '16px' }}>
              {/* Post image */}
              <img src="https://static1.colliderimages.com/wordpress/wp-content/uploads/2021/07/indie-games.jpg" alt="Post 1" style={{ width: '100%', height: 'auto', marginBottom: '10px' }} />
              {/* Post title */}
              <Typography variant="h6" gutterBottom>
              Best Indie Games You Should Try
              </Typography>
              {/* Post description */}
              <Typography variant="body2" gutterBottom>
              Check out these amazing indie games that are making waves in the gaming community.
              </Typography>
              {/* Post author */}
              <Typography variant="body2" color="textSecondary">
                By Matthew Jones
              </Typography>
            </Paper>
          </Grid>

          <Grid item xs={12} sm={6} md={4}>
            <Paper style={{ padding: '16px' }}>
              {/* Post image */}
              <img src="https://cdn.sanity.io/images/zoz4y99f/production/63fe73d90694450859da70fe142d72e445a0a9cc-1600x900.jpg?w=1600&auto=format" alt="Post 1" style={{ width: '100%', height: 'auto', marginBottom: '10px' }} />
              {/* Post title */}
              <Typography variant="h6" gutterBottom>
              The Evolution of Esports
              </Typography>
              {/* Post description */}
              <Typography variant="body2" gutterBottom>
              Discover how esports has grown into a global phenomenon.
              </Typography>
              {/* Post author */}
              <Typography variant="body2" color="textSecondary">
                By Emily Johnson
              </Typography>
            </Paper>
          </Grid>
        </Grid>
      </Container>
    </div>
  );
};

export default Home;
